AngularJS
=========

Shim repository for [AngularJS](http://github.com/angular/angular.js).

Package Managers
----------------

* [Component](https://github.com/component/component): `components/angular.js`
* [Composer](http://packagist.org/packages/components/angular.js): `components/angular.js`
